﻿using ProjetoBase.Model;
using ProjetoBase.Model.Repository;
using System;
using System.Windows.Forms;

namespace ProjetoBase.ViewController
{
    /// <summary>
    /// Classe equivalente ao Controlador da ContatoView.
    /// Referencia: https://www.c-sharpcorner.com/UploadFile/1e050f/insert-update-and-delete-record-in-datagridview-C-Sharp/
    /// </summary>
    public partial class ContatoView : Form
    {
        private ContatoRepository repository = ContatoRepositorySqlDb.Instance;

        public ContatoView()
        {
            InitializeComponent();

            CarregarGrid();
        }

        private void CarregarGrid()
        {
            BindingSource source = new BindingSource();
            source.DataSource = repository.Read();
            dataGridViewContatos.DataSource = source;
            dataGridViewContatos.ClearSelection();

            HabilitarCamposDependentes(false);
        }

        private void HabilitarCamposDependentes(Boolean habilitar)
        {
            buttonAlterar.Enabled = habilitar;
            buttonExcluir.Enabled = habilitar;
        }

        private int LinhaSelecionada()
        {
            return dataGridViewContatos.CurrentRow.Index;
        }

        private void LimparCampos()
        {
            textBoxNome.Text = "";
            textBoxTelefone.Text = "";
        }

        private void buttonInserir_Click(object sender, EventArgs e)
        {
            Contato contato = new Contato();
            contato.Nome = textBoxNome.Text;
            contato.Telefone = textBoxTelefone.Text;

            repository.Create(contato);

            CarregarGrid();

            MessageBox.Show("Contato inserido com sucesso!");

            LimparCampos();
        }

        private void buttonAlterar_Click(object sender, EventArgs e)
        {
            Contato contato = new Contato();
            contato.Id = Convert.ToInt64(dataGridViewContatos.Rows[LinhaSelecionada()].Cells[0].Value);
            contato.Nome = textBoxNome.Text;
            contato.Telefone = textBoxTelefone.Text;

            repository.Update(contato);

            CarregarGrid();

            MessageBox.Show("Contato alterado com sucesso!");

            LimparCampos();
        }

        private void buttonExcluir_Click(object sender, EventArgs e)
        {
            Contato contato = new Contato();
            contato.Id = Convert.ToInt64(dataGridViewContatos.Rows[LinhaSelecionada()].Cells[0].Value);

            repository.Delete(contato);

            CarregarGrid();

            MessageBox.Show("Contato excluido com sucesso!");

            LimparCampos();
        }

        private void dataGridViewContatos_SelectionChanged(object sender, EventArgs e)
        {
            HabilitarCamposDependentes(true);

            textBoxNome.Text = dataGridViewContatos.Rows[LinhaSelecionada()].Cells[1].Value as string;
            textBoxTelefone.Text = dataGridViewContatos.Rows[LinhaSelecionada()].Cells[2].Value as string;
        }
    }
}
