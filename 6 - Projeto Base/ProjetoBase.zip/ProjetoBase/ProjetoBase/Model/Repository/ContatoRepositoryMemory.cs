﻿using System.Collections.Generic;
using System.Linq;

namespace ProjetoBase.Model.Repository
{
    public class ContatoRepositoryMemory : ContatoRepository
    {
        #region Singleton

        private static ContatoRepositoryMemory instance = new ContatoRepositoryMemory();

        private ContatoRepositoryMemory() { }

        public static ContatoRepository Instance { get { return instance; } }

        #endregion Singleton

        private long contador = 0;
        private List<Contato> contatos = new List<Contato>();

        public void Create(Contato contato)
        {
            contato.Id = contador++;
            contatos.Add(contato);
        }

        public void Delete(Contato contato)
        {
            contatos.RemoveAll(item => item.Id == contato.Id);
        }

        public List<Contato> Read()
        {
            return contatos;
        }

        public void Update(Contato contato)
        {
            Contato contatoAntigo = contatos.Single(item => item.Id == contato.Id);
            contatoAntigo.Nome = contato.Nome;
            contatoAntigo.Telefone = contato.Telefone;
        }
    }
}
