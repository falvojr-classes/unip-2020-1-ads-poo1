﻿using System.Collections.Generic;

namespace ProjetoBase.Model.Repository
{
    public interface ContatoRepository
    {
        void Create(Contato contato);
        List<Contato> Read();
        void Update(Contato contato);
        void Delete(Contato contato);
    }
}
