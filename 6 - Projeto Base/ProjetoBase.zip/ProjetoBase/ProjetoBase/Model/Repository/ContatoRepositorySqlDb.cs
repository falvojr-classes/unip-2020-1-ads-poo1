﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;

namespace ProjetoBase.Model.Repository
{
    public class ContatoRepositorySqlDb : ContatoRepository
    {
        #region Singleton

        private static ContatoRepositorySqlDb instance = new ContatoRepositorySqlDb();

        private ContatoRepositorySqlDb() { }

        public static ContatoRepository Instance { get { return instance; } }

        #endregion Singleton

        private string AgendaConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["AgendaConnectionString"].ConnectionString;
        }

        public void Create(Contato contato)
        {
            using (SqlConnection conexao = new SqlConnection(AgendaConnectionString()))
            {
                conexao.Open();

                SqlCommand comando = new SqlCommand("INSERT INTO tb_contatos(Nome,Telefone) VALUES(@nome,@telefone)", conexao);
                comando.Parameters.AddWithValue("@nome", contato.Nome);
                comando.Parameters.AddWithValue("@telefone", contato.Telefone);
                comando.ExecuteNonQuery();
            }
        }

        public void Delete(Contato contato)
        {
            using (SqlConnection conexao = new SqlConnection(AgendaConnectionString()))
            {
                conexao.Open();

                SqlCommand comando = new SqlCommand("DELETE tb_contatos WHERE Id = @id", conexao);
                comando.Parameters.AddWithValue("@id", contato.Id);
                comando.ExecuteNonQuery();
            }
        }

        public List<Contato> Read()
        {
            using (SqlConnection conexao = new SqlConnection(AgendaConnectionString()))
            {
                conexao.Open();

                List<Contato> contatos = new List<Contato>();
                SqlCommand comando = new SqlCommand("SELECT * FROM tb_contatos", conexao);
                using (SqlDataReader leitor = comando.ExecuteReader())
                {
                    while (leitor.Read())
                    {
                        Contato contato = new Contato();
                        contato.Id = Convert.ToInt64(leitor["Id"]);
                        contato.Nome = leitor["Nome"] as string;
                        contato.Telefone = leitor["Telefone"] as string;
                        contatos.Add(contato);
                    }
                }
                return contatos;
            }
        }

        public void Update(Contato contato)
        {
            using (SqlConnection conexao = new SqlConnection(AgendaConnectionString()))
            {
                conexao.Open();

                SqlCommand comando = new SqlCommand("UPDATE tb_contatos SET Nome=@nome, Telefone=@telefone WHERE Id = @id", conexao);
                comando.Parameters.AddWithValue("@nome", contato.Nome);
                comando.Parameters.AddWithValue("@telefone", contato.Telefone);
                comando.Parameters.AddWithValue("@id", contato.Id);
                comando.ExecuteNonQuery();
            }
        }
    }
}
